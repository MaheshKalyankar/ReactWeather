var names = ['mahesh','akanksha'];

names.forEach((name) => console.log(name));